/* Copyright (C) 2010 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.grails.datastore.gorm.plugin.support.ApplicationContextConfigurer
import org.grails.datastore.gorm.redis.plugin.support.RedisMethodsConfigurer
import org.grails.datastore.gorm.redis.plugin.support.RedisOnChangeHandler
import org.grails.datastore.gorm.redis.plugin.support.RedisSpringConfigurer

class RedisGormGrailsPlugin {
    def license = "Apache 2.0 License"
    def organization = [ name: "Pivotal", url: "http://gopivotal.com/oss" ]
    def developers = [
        [ name: "Graeme Rocher", email: "grocher@vmware.com" ] ]
    def issueManagement = [ system: "JIRA", url: "http://jira.grails.org/browse/GPREDIS" ]
    def scm = [ url: "https://github.com/grails/grails-data-mapping" ]

    def version = "1.0.0"
    def grailsVersion = "2.3.0 > *"
    def loadAfter = ['domainClass', 'hibernate', 'services', 'cloudFoundry']
    def observe = ['services', 'domainClass']
    
    def author = "Graeme Rocher"
    def authorEmail = "grocher@gopivotal.com"
    def title = "Redis GORM"
    def description = 'A plugin that integrates the Redis key/value datastore into Grails, providing a GORM-like API onto it'

    def pluginExcludes = [
        "grails-app/domain/*.groovy",
        "grails-app/services/*.groovy",
        "grails-app/controllers/*.groovy"
    ]

    def documentation = "http://grails.github.io/grails-data-mapping/redis/"

    def doWithSpring = new RedisSpringConfigurer().getConfiguration()
    
    def doWithDynamicMethods = { ctx ->
        def datastore = ctx.redisDatastore
        def transactionManager = ctx.redisDatastoreTransactionManager
        def methodsConfigurer = new RedisMethodsConfigurer(datastore, transactionManager)    
        methodsConfigurer.hasExistingDatastore = manager.hasGrailsPlugin("hibernate")        
        def foe = application?.config?.grails?.gorm?.failOnError
        methodsConfigurer.failOnError = foe instanceof Boolean ? foe : false        
        methodsConfigurer.configure()
    }

    def doWithApplicationContext = { ctx ->
        new ApplicationContextConfigurer("Redis").configure(ctx)
    }
    
    def onChange = { event ->
        if(event.ctx) {
            new RedisOnChangeHandler(event.ctx.redisDatastore, event.ctx.redisDatastoreTransactionManager).onChange(delegate, event)            
        }
    }
}
